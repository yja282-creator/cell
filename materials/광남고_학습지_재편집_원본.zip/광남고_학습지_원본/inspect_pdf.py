from pathlib import Path
import fitz,json
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output';IMAGES=OUT/'pages';IMAGES.mkdir(exist_ok=True)
PDF=OUT/'광남고_세포분열_탐구_학습지_학생용.pdf'
doc=fitz.open(PDF)
issues=[];links=[];fonts=set()
assert len(doc)==8
for i,p in enumerate(doc):
 assert abs(p.rect.width-595.2756)<.1 and abs(p.rect.height-841.8898)<.1
 text=p.get_text()
 assert text.strip(),f'Blank page {i+1}'
 assert '\ufffd' not in text and '□' not in text,f'Broken glyph {i+1}'
 for font in p.get_fonts(full=True):
  fonts.add(font[3]);_,_,_,binary=doc.extract_font(font[0]);assert binary,f'Font not embedded {font}'
  assert 'Pretendard' in font[3],font
 for link in p.get_links():
  if link['kind']==fitz.LINK_GOTO:
   assert 0<=link['page']<len(doc)
   links.append({'from':i+1,'to':link['page']+1})
  elif link['kind']==fitz.LINK_NAMED and str(link.get('page','')).isdigit():
   target=int(link['page']);assert 1<=target<=len(doc)
   links.append({'from':i+1,'to':target})
 pix=p.get_pixmap(matrix=fitz.Matrix(1.65,1.65),alpha=False);pix.save(IMAGES/f'page-{i+1:02}.png')
 if 3<=i+1<=7:
  for block in p.get_text('dict')['blocks']:
   if 'lines' not in block:continue
   for line in block['lines']:
    for span in line['spans']:
     x0,y0,x1,y1=span['bbox'];mid=(y0+y1)/2/(72/25.4)
     if mid<25 or mid>277:continue # masthead/footer have their own rules.
     if x0/(72/25.4)<19.9 or x1/(72/25.4)>190.1 or y0/(72/25.4)<31.9 or y1/(72/25.4)>268.1:
      issues.append({'page':i+1,'text':span['text'],'bbox_mm':[round(v/(72/25.4),2) for v in (x0,y0,x1,y1)]})
assert not issues,issues
assert len(links)==7,links
expected={(2,3),(2,4),(2,6),(4,4),(4,5),(6,6),(6,7)}
assert {(a['from'],a['to']) for a in links}==expected
# Correct reading order: front cover alone, then even-left/odd-right spreads, back cover alone.
spread_paths=[]
for pair in [(None,1),(2,3),(4,5),(6,7),(8,None)]:
 sample=Image.open(IMAGES/'page-01.png');w,h=sample.size
 im=Image.new('RGB',(w*2+18,h),'#e8e9e8')
 for slot,n in enumerate(pair):
  if n:im.paste(Image.open(IMAGES/f'page-{n:02}.png'),(slot*(w+18),0))
 path=OUT/f'spread-{pair[0] or 0}-{pair[1] or 0}.png';im.save(path);spread_paths.append(path)
# Three interior spreads in one shareable preview; full-resolution pages stay in the source ZIP.
thumbs=[]
for path in spread_paths[1:4]:
 im=Image.open(path);im.thumbnail((1300,1100));thumbs.append(im)
contact=Image.new('RGB',(1300,sum(i.height for i in thumbs)+40),'#e8e9e8');y=0
for im in thumbs:contact.paste(im,((1300-im.width)//2,y));y+=im.height+20
contact.save(OUT/'광남고_학습지_펼침면_미리보기.png')
report={'pages':len(doc),'a4':True,'embedded_fonts':sorted(fonts),'internal_links':links,'body_margin_violations':issues,'broken_glyphs':False,'body_pages':6,'covers':2,'printing':'A4 / no bleed / no binding','sections':{'I':[4,5],'II':[6,7]}}
(OUT/'검사결과.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
