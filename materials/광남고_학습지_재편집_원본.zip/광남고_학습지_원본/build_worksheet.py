"""Build the approved A4 student booklet. Python: reportlab, fonttools, pymupdf, pillow."""
from pathlib import Path
from functools import lru_cache
from xml.sax.saxutils import escape
import json, math, colorsys, shutil, zipfile
import fitz
from PIL import Image, ImageDraw, ImageFont
from fontTools.ttLib import TTFont as FontSource
from fontTools.pens.boundsPen import BoundsPen
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import Color, HexColor, black, white
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
FONTS=ROOT/'fonts'
LOGO=ROOT/'gwangnam-class-logo.svg'
MM=72/25.4
W,H=210*MM,297*MM
TITLE='광남고 세포분열 탐구 학습지'
MINT=HexColor('#BCE1DF');GREEN=HexColor('#B5D893');SKY=HexColor('#AECEE2')
COLORS={3:MINT,4:MINT,5:MINT,6:GREEN,7:GREEN}
SECTION={3:'시작하기',4:'Ⅰ 체세포분열',5:'Ⅰ 체세포분열',6:'Ⅱ 감수분열과 비교',7:'Ⅱ 감수분열과 비교'}
for name in ['Regular','SemiBold','Bold','Light']:
    pdfmetrics.registerFont(TTFont(name,str(FONTS/f'Pretendard-{name}.ttf')))
FONT_SRC={n:FontSource(FONTS/f'Pretendard-{n}.ttf') for n in ['Regular','SemiBold','Bold','Light']}
TEXT_RECORDS=[]

def tint(c,p):return Color(1-(1-c.red)*p,1-(1-c.green)*p,1-(1-c.blue)*p)
def dark(c):
    h,l,s=colorsys.rgb_to_hls(c.red,c.green,c.blue)
    return Color(*colorsys.hls_to_rgb(h,.36,s))

def text(c,x,y,s,size=12,font='Regular',color=black,align='left',spacing=0):
    width=pdfmetrics.stringWidth(s,font,size)+max(0,len(s)-1)*spacing
    left=x if align=='left' else x-width/MM/2 if align=='center' else x-width/MM
    c.setFillColor(color)
    obj=c.beginText(left*MM,(297-y)*MM);obj.setFont(font,size);obj.setCharSpace(spacing);obj.textOut(s);c.drawText(obj)
    TEXT_RECORDS.append({'page':c.getPageNumber(),'text':s,'left_mm':round(left,2),'right_mm':round(left+width/MM,2),'baseline_mm':y,'size':size})

@lru_cache(maxsize=512)
def glyph_vertical(s,font):
    f=FONT_SRC[font];glyphs=f.getGlyphSet();cm=f.getBestCmap();bounds=[]
    for ch in s:
        if ch==' ':continue
        if ord(ch) not in cm:raise ValueError(f'Unavailable glyph {ch!r} in {font}')
        pen=BoundsPen(glyphs);glyphs[cm[ord(ch)]].draw(pen)
        if pen.bounds:bounds.append(pen.bounds)
    return (min(b[1] for b in bounds)/f['head'].unitsPerEm,max(b[3] for b in bounds)/f['head'].unitsPerEm) if bounds else (0,0)

def centered(c,x,y,w,h,s,size=12,font='Regular',color=black):
    low,high=glyph_vertical(s,font)
    baseline=y+h/2+(high+low)*size/MM/2
    text(c,x+w/2,baseline,s,size,font,color,'center')

def para(c,x,y,w,s,font='Regular',size=12,leading=6.2):
    st=ParagraphStyle('body',fontName=font,fontSize=size,leading=leading*MM,textColor=black,splitLongWords=False,spaceAfter=0,allowWidows=0,allowOrphans=0)
    p=Paragraph(escape(s).replace('\n','<br/>'),st)
    ww,hh=p.wrap(w*MM,1000)
    p.drawOn(c,x*MM,(297-y)*MM-hh)
    TEXT_RECORDS.append({'page':c.getPageNumber(),'text':s,'left_mm':x,'right_mm':x+w,'top_mm':y,'bottom_mm':y+hh/MM,'size':size})
    return y+hh/MM

def rr(c,x,y,w,h,fill=None,stroke=None,r=3,lw=1):
    c.setLineWidth(lw)
    if fill:c.setFillColor(fill)
    if stroke:c.setStrokeColor(stroke)
    c.roundRect(x*MM,(297-y-h)*MM,w*MM,h*MM,r*MM,fill=bool(fill),stroke=bool(stroke))

def rule(c,x,y,w,color,lw=.5,dash=None):
    c.setStrokeColor(color);c.setLineWidth(lw);c.setDash(dash or [])
    c.line(x*MM,(297-y)*MM,(x+w)*MM,(297-y)*MM);c.setDash()

def answer(c,y,lines=2,color=MINT,x=20,w=170,gap=8):
    for i in range(lines):rule(c,x,y+i*gap,w,tint(color,.6),.5)

def chip(c,x,y,w,label,target,color=MINT):
    rr(c,x,y,w,5.4,tint(color,.4),color,2.7,.6)
    centered(c,x,y,w,5.4,label,9.5,'SemiBold')
    c.linkRect('',f'page{target}',(x*MM,(297-y-5.4)*MM,(x+w)*MM,(297-y)*MM),relative=0,thickness=0)

def footer(c,page,color,name):
    if page%2==0:
        text(c,20,286,str(page),12,color=HexColor('#4F4F4F'))
        text(c,28,286,'…',18,color=HexColor('#CCCCCC'))
        text(c,39,286,name,12,color=HexColor('#999999'),spacing=-.24)
    else:
        text(c,190,286,str(page),12,color=HexColor('#4F4F4F'),align='right')
        text(c,182,286,'…',18,color=HexColor('#CCCCCC'),align='right')
        text(c,171,286,name,12,color=HexColor('#999999'),align='right',spacing=-.24)

def base(c,page):
    col=COLORS[page];name=SECTION[page]
    # 2pt rounded dashed line; even-page L tab clips its own diagonal stripes.
    rule(c,47 if page%2==0 else 0,18,163 if page%2==0 else 210,tint(col,.4),2,[3,5])
    if page%2==0:
        p=c.beginPath();p.moveTo(0,H);p.lineTo(47*MM,H);p.lineTo(47*MM,H-18*MM);p.lineTo(22*MM,H-18*MM)
        p.curveTo(19*MM,H-18*MM,19*MM,H-21*MM,19*MM,H-24*MM);p.lineTo(19*MM,H-42*MM);p.lineTo(0,H-42*MM);p.close()
        c.saveState();c.setFillColor(tint(col,.4));c.drawPath(p,fill=1,stroke=0);c.clipPath(p,stroke=0,fill=0)
        c.setStrokeColor(col);c.setLineWidth(1.6)
        for i in range(-70,100):
            xx=i*3.1;c.line(xx,H-50*MM,xx+60*MM,H+10*MM)
        c.restoreState()
    else:
        first='2026 광남고등학교';second='  '+TITLE;size=9;spacing=-.225
        sw=pdfmetrics.stringWidth(second,'Regular',size)+(len(second)-1)*spacing
        text(c,190,15.8,second,size,color=HexColor('#999999'),align='right',spacing=spacing)
        text(c,190-sw/MM,15.8,first,size,color=col,align='right',spacing=spacing)
    footer(c,page,col,name)

def opener(c,roman,title,color,chips):
    c.setFillColor(tint(color,.3));c.circle(44*MM,(297-60.1)*MM,24.5*MM,fill=1,stroke=0)
    c.setFillColor(color);c.circle(47*MM,(297-62)*MM,16*MM,fill=1,stroke=0)
    centered(c,31,45.4,32,32,roman,44 if roman=='Ⅰ' else 25,'Light')
    text(c,76.5,57.5,title,26,'Bold');rule(c,76.5,63,113.5,color,2.2)
    x=76.5
    for label,target,w in chips:
        rr(c,x,66.8,w,8,tint(color,.25),r=4)
        centered(c,x,66.8,w,8,label,12,'Bold')
        c.linkRect('',f'page{target}',(x*MM,(297-74.8)*MM,(x+w)*MM,(297-66.8)*MM),relative=0,thickness=0)
        x+=w+3

def bar(c,y,num,title,color):
    rr(c,24,y+.75,166,9.5,tint(color,.12),color,4.75,1)
    rr(c,20,y,11,11,color,r=2.2)
    centered(c,20,y,11,11,str(num),12,'Bold')
    centered(c,33,y+.75,154,9.5,title,12,'Bold')

def table(c,y,headers,rows,widths,row_heights=None,color=MINT,header_h=10):
    x=20;total=sum(widths)
    rr(c,x,y,total,header_h,color,r=2.2)
    c.setFillColor(color);c.rect(x*MM,(297-y-header_h)*MM,total*MM,header_h*MM/2,fill=1,stroke=0)
    xx=x
    for label,w in zip(headers,widths):centered(c,xx,y,w,header_h,label,12,'SemiBold');xx+=w
    yy=y+header_h
    for i,row in enumerate(rows):
        rh=(row_heights[i] if isinstance(row_heights,list) else row_heights) or 10
        xx=x
        for j,(s,w) in enumerate(zip(row,widths)):
            if j==0:
                c.setFillColor(HexColor('#F4F4F4'));c.rect(xx*MM,(297-yy-rh)*MM,w*MM,rh*MM,fill=1,stroke=0)
            font='SemiBold' if j==0 else 'Regular'
            if s:
                if len(s)<=14 and '\n' not in s and pdfmetrics.stringWidth(s,font,12)<(w-5.2)*MM:
                    centered(c,xx+2.6,yy,w-5.2,rh,s,12,font)
                else:
                    st=ParagraphStyle('cell',fontName=font,fontSize=12,leading=5.6*MM,textColor=black,splitLongWords=False)
                    p=Paragraph(escape(s).replace('\n','<br/>'),st);_,hh=p.wrap((w-5.2)*MM,1000)
                    if hh>(rh-5.2)*MM+.1:raise ValueError(f'Cell too tall on page {c.getPageNumber()}: {s} ({hh/MM:.1f} > {rh-5.2})')
                    p.drawOn(c,(xx+2.6)*MM,(297-yy-rh/2)*MM-hh/2)
                    TEXT_RECORDS.append({'page':c.getPageNumber(),'text':s,'left_mm':xx+2.6,'right_mm':xx+w-2.6,'top_mm':yy+(rh-hh/MM)/2,'bottom_mm':yy+(rh+hh/MM)/2,'size':12})
            xx+=w
        rule(c,x,yy+rh,total,tint(color,.6),.5);yy+=rh
    xx=x
    for j,w in enumerate(widths):
        c.setStrokeColor(color if j==1 else tint(color,.6));c.setLineWidth(.8 if j==1 else .5)
        c.line(xx*MM,(297-y-header_h)*MM,xx*MM,(297-yy)*MM);xx+=w
    c.setStrokeColor(tint(color,.6));c.setLineWidth(.5);c.line(xx*MM,(297-y-header_h)*MM,xx*MM,(297-yy)*MM)
    rule(c,x,yy,total,color,1.6)
    return yy

def important(c,y,title,s,color,h=42):
    rr(c,20,y,170,h,tint(color,.08),color,3.5,1.2)
    rr(c,20.2,y+.2,169.6,12.5,tint(color,.25),r=3.3)
    c.setFillColor(tint(color,.25));c.rect(20.2*MM,(297-y-12.7)*MM,169.6*MM,6*MM,fill=1,stroke=0)
    labelw=pdfmetrics.stringWidth(title,'Bold',12)/MM+10
    rr(c,25,y-4.1,labelw,8.2,color,r=4.1)
    centered(c,25,y-4.1,labelw,8.2,title,12,'Bold')
    return para(c,25,y+19.5,160,s)

def qa(c,y,q,a,color):
    rr(c,20,y,170,10,tint(color,.12),r=3)
    rr(c,20,y,16,10,color,r=3);centered(c,20,y,16,10,'Q',12,'Bold')
    centered(c,39,y,146,10,q,12,'SemiBold')
    rr(c,20,y+12,14,11.5,tint(color,.25),r=3);centered(c,20,y+12,14,11.5,'A',12,'Bold')
    st=ParagraphStyle('a',fontName='Regular',fontSize=12,leading=6.2*MM,splitLongWords=False)
    p=Paragraph(escape(a),st);_,hh=p.wrap(148*MM,1000);h=hh/MM+5.6
    rr(c,36,y+12,154,h,white,color,r=3,lw=1);p.drawOn(c,39*MM,(297-y-14.8)*MM-hh)
    return y+12+h

def newpage(c,n):
    c.bookmarkPage(f'page{n}')
    if n in COLORS:base(c,n)

def build():
    path=OUT/'광남고_세포분열_탐구_학습지_학생용.pdf'
    c=canvas.Canvas(str(path),pagesize=(W,H),pageCompression=1,initialFontName='Regular',initialFontSize=12,initialLeading=6.2*MM)
    c.setTitle(TITLE);c.setAuthor('광남고등학교');c.setSubject('고등학생 50분 시뮬레이션 탐구 수업 · 학생용')
    c.setLineCap(1)
    # 1. Cover: the approved logo, no external photographs.
    newpage(c,1);c.setFillColor(MINT);c.rect(0,0,W,H,fill=1,stroke=0)
    c.setFillColor(tint(MINT,.3));c.circle(186*MM,(297-32)*MM,66*MM,fill=1,stroke=0)
    c.setFillColor(tint(MINT,.6));c.circle(4*MM,(297-255)*MM,58*MM,fill=1,stroke=0)
    text(c,24,44,'관찰하고, 비교하고, 설명하기',15,'SemiBold',dark(MINT))
    text(c,24,64,'2026',18,'SemiBold',dark(MINT));text(c,24,81,'광남고등학교',20,'SemiBold')
    for yy,s in [(118,'광남고'),(140,'세포분열'),(162,'탐구 학습지')]:text(c,24,yy,s,40,'Bold')
    text(c,24,184,'고등학생 · 50분 시뮬레이션 탐구',14,'SemiBold',dark(MINT))
    text(c,24,197,'학생용 / 관찰표 중심',12,'Regular',dark(MINT))
    # Rasterized from the previously approved vector, at high resolution.
    svg=fitz.open(LOGO);pix=svg[0].get_pixmap(matrix=fitz.Matrix(5,5),alpha=True);logo_png=OUT/'logo.png';pix.save(logo_png)
    c.drawImage(str(logo_png),88*MM,28*MM,34*MM,34*MM,mask='auto')
    c.showPage()
    # 2. Contents. Even physical page on the left; no decorative header.
    newpage(c,2)
    text(c,20,33,TITLE,11,'SemiBold',HexColor('#666666'))
    text(c,20,45,'CONTENTS',9,'SemiBold',HexColor('#666666'),spacing=1.08)
    text(c,20,66,'목차',34,'Bold')
    toc=[('시작','시작하기',3,MINT),('Ⅰ','체세포분열',4,MINT),('Ⅱ','감수분열과 비교',6,GREEN)]
    details=[('사용 방법과 관찰 기준',3),('단계별 관찰 · 움직임과 수 세기',4),('감수 I·II 관찰 · 비교와 교차 탐구',6)]
    for i,((tag,title,page,col),(item,_,)) in enumerate(zip(toc,details)):
        yy=91+i*44
        c.setFillColor(tint(col,.3));c.circle(38*MM,(297-yy)*MM,18*MM,fill=1,stroke=0)
        c.setFillColor(col);c.circle(38*MM,(297-yy)*MM,13*MM,fill=1,stroke=0)
        centered(c,25,yy-13,26,26,tag,15 if tag=='시작' else 25,'Bold',white)
        text(c,64,yy-2,title,18,'Bold',dark(col));rule(c,64,yy+5,126,col,1.6)
        text(c,64,yy+15,item,12,'SemiBold',HexColor('#2B2B2B'))
        leader_start=64+pdfmetrics.stringWidth(item,'SemiBold',12)/MM+4
        rule(c,leader_start,yy+14,181-leader_start,tint(col,.6),.6,[1,2.5])
        text(c,188,yy+15,str(page),12,'Bold',dark(col),'right')
        c.linkRect('',f'page{page}',(20*MM,(297-yy-21)*MM,190*MM,(297-yy+19)*MM),relative=0,thickness=0)
    text(c,20,235,'수업 흐름',12,'Bold')
    para(c,20,242,170,'준비 5분 → 체세포분열 15분 → 감수분열 15분\n비교 탐구 10분 → 마무리 5분')
    text(c,105,286,'2',8,color=HexColor('#8C8C8C'),align='center');c.showPage()
    # 3. Setup and two compact Q&A pairs.
    newpage(c,3);text(c,20,48,'시작하기',26,'Bold')
    text(c,20,63,'학년       반       번    이름 __________________',12)
    text(c,20,75,'짝 이름 __________________    수업 날짜 __________',12)
    bar(c,86,1,'화면을 조작하며 관찰하기',MINT)
    table(c,107,['화면 조작','할 일'],[
        ('분열 종류 탭','체세포분열과 감수분열을 선택한다.'),
        ('재생 · 일시정지','0.5× 속도로 움직임을 관찰한다.'),
        ('단계 · 진행률','타임라인을 누르고 슬라이더를 움직인다.'),
        ('관찰 설정','방추사·구조 이름·교차 표현을 켜고 끈다.')
    ],[49,121],row_heights=13,color=MINT)
    para(c,20,174,170,'관찰 기준: 이 모형은 2n = 4인 동물세포이다.\n염색체 수는 동원체 수로 세며, C는 반수체 DNA량이다.')
    end=qa(c,195,'간기도 분열기에 포함되나요?','간기는 분열 전 준비 단계이다. 이 학습지에서는 DNA 복제를 비교하려고 함께 관찰한다.',MINT)
    qa(c,end+7,'실제 세포와 완전히 같은가요?','시간·크기는 실제 비율이 아니다. 감수 I의 핵막 형성은 생물마다 다르고, 이 모형은 교차의 한 사례를 보여 준다.',MINT)
    c.showPage()
    # 4. Mitosis observations. Opening section starts on an even page.
    newpage(c,4);opener(c,'Ⅰ','체세포분열',MINT,[('단계 관찰',4,37),('이동과 수',5,37)])
    bar(c,96,1,'단계를 멈추고 특징 기록하기',MINT)
    para(c,20,115,170,'일시정지한 뒤 각 단계의 특징을 짧게 쓴다.')
    table(c,128,['단계','염색체 모양·위치','방추사·핵막 변화'],[
        ('간기','',''),('전기','',''),('중기','',''),('후기','',''),('말기','',''),('세포질분열','','')
    ],[34,71,65],row_heights=16,color=MINT)
    para(c,20,242,170,'X자 모양 한 개는 염색체 몇 개, 염색분체 몇 개인가?')
    answer(c,258,1,MINT)
    c.showPage()
    # 5. Drawing and counting: one cell vs one pole is made explicit.
    newpage(c,5);bar(c,48,2,'염색체 이동을 그려 설명하기',MINT)
    para(c,20,67,170,'중기와 후기를 비교한다. 염색체와 방추사를 그리고,\n화살표로 염색체가 움직이는 방향을 표시한다.')
    for xx,label in [(20,'중기'),(110,'후기')]:
        rr(c,xx,86,80,43,white,MINT,3,1)
        centered(c,xx,88,80,7,label,12,'SemiBold')
        c.setStrokeColor(tint(MINT,.6));c.setLineWidth(.6);c.ellipse((xx+9)*MM,(297-123)*MM,(xx+71)*MM,(297-99)*MM,stroke=1,fill=0)
    para(c,20,138,170,'방추사 표시를 꺼도 화면의 염색체는 움직인다.\n이 조작만으로 방추사가 필요 없다고 결론 낼 수 있을까?\n표시 설정과 실제 세포의 차이를 생각하여 쓰자.')
    answer(c,162,2,MINT)
    bar(c,183,3,'염색체 수와 DNA량 구별하기',MINT)
    table(c,205,['관찰 시점','염색체 수','DNA량'],[
        ('DNA 복제 전','______ 개','______ C'),
        ('복제 후 · 중기','______ 개','______ C'),
        ('후기 · 한 세포 전체','______ 개','______ C'),
        ('완성된 딸세포 1개','______ 개','______ C')
    ],[78,46,46],row_heights=12,color=MINT)
    c.showPage()
    # 6. One matched table for meiosis I and II, avoiding 11 tiny separate rows.
    newpage(c,6);opener(c,'Ⅱ','감수분열과 비교',GREEN,[('감수 I·II',6,39),('비교 탐구',7,39)])
    bar(c,96,1,'감수 I과 II를 나란히 관찰하기',GREEN)
    para(c,20,115,170,'감수 II 전에는 DNA를 다시 복제하는지 먼저 확인한다.')
    table(c,128,['단계','감수 I','감수 II'],[
        ('전기','짝짓기·교차:\n________________','새 DNA 복제:\n________________'),
        ('중기','정렬 단위:\n________________','정렬 단위:\n________________'),
        ('후기','분리되는 대상:\n________________','분리되는 대상:\n________________'),
        ('말기','핵 하나의 염색체 수:\n____________ 개','핵 하나의 염색체 수:\n____________ 개'),
        ('세포질분열','생성 세포 수:\n____________ 개','생성 세포 수:\n____________ 개')
    ],[30,70,70],row_heights=21,color=GREEN)
    para(c,20,248,170,'생성 세포 수는 처음 세포 한 개에서 나온 전체 수이다.\n간기의 DNA 복제는 감수 I 이전에 한 번만 관찰한다.')
    c.showPage()
    # 7. Comparison, a real toggle inquiry, and an exit response.
    newpage(c,7);bar(c,48,2,'같은 출발, 다른 결과 비교하기',GREEN)
    table(c,69,['비교 기준','체세포분열','감수분열'],[
        ('분열 횟수','______ 회','______ 회'),
        ('최종 세포 수','______ 개','______ 개'),
        ('딸세포 하나의 염색체','______ 개 · 2n','______ 개 · n'),
        ('딸세포 하나의 DNA량','______ C','______ C')
    ],[78,46,46],row_heights=12,color=GREEN)
    bar(c,139,3,'교차 표현을 바꾸어 탐구하기',GREEN)
    para(c,20,158,170,'감수분열의 중기 I에서 교차 표현을 켰다 끈다.\n염색체의 색 구간은 어떻게 달라지는가?\n교차로 염색체 수나 전체 DNA량도 달라지는가?')
    answer(c,182,2,GREEN)
    bar(c,205,4,'마무리: 관찰 근거로 설명하기',GREEN)
    para(c,20,224,170,'“감수 I과 감수 II는 같은 대상을 분리한다.”\n이 문장을 고치고, 후기 I·II에서 본 근거를 쓰자.')
    answer(c,244,3,GREEN)
    c.showPage()
    # 8. Back cover. User explicitly requested omission of unprovided contact/date fields.
    newpage(c,8);c.setFillColor(tint(MINT,.4));c.rect(0,0,W,H,fill=1,stroke=0)
    c.drawImage(str(logo_png),88*MM,(297-82)*MM,34*MM,34*MM,mask='auto')
    text(c,105,111,TITLE,20,'Bold',dark(MINT),'center')
    text(c,105,127,'광남고등학교 · 학생용',14,'SemiBold',dark(MINT),'center')
    rows=[('발행처','광남고등학교'),('발행연도','2026'),('기반 자료','CELL 세포분열 시뮬레이션'),('구성','관찰 · 비교 · 근거 설명')]
    for i,(a,b) in enumerate(rows):
        y=175+i*9;text(c,31,y,a,12,'SemiBold');text(c,67,y,b,12)
    text(c,105,234,'수업용으로 만든 광남고 마름모 로고를 사용했습니다.',10.5,color=dark(MINT),align='center')
    text(c,105,250,'이름 __________________    반납일 ______________',12,color=dark(MINT),align='center')
    c.showPage();c.save()
    (OUT/'text-layout-records.json').write_text(json.dumps(TEXT_RECORDS,ensure_ascii=False,indent=2))
    print(path)
    return path

if __name__=='__main__':build()
