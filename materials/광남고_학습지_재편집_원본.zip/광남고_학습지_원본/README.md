# 광남고 세포분열 탐구 학습지 · 재편집 원본

## 구성
- `build_worksheet.py`: 학생용 PDF 생성 코드. 질문·표 항목·배치값도 이 파일에 들어 있습니다.
- `inspect_pdf.py`: 페이지별 PNG, 펼침면 미리보기 및 검사 결과 생성.
- `fonts/`: 공식 Pretendard Regular·SemiBold·Bold·Light 원본과 OFL 라이선스.
- `gwangnam-class-logo.svg`: 사용자가 승인한 수업용 마름모 광남고 로고.
- `제작지침_확정본.md`: 원래 지침 전체에 사용자가 확정한 정보와 예외를 반영한 문서.
- `output/`: 납품 PDF, 각 쪽 이미지, 펼침면 이미지, 검사 기록.

## 다시 만들기
Python 3.12에서 확인했습니다. 이 폴더에서 다음 명령을 실행합니다.

```sh
python -m pip install -r requirements.txt
python build_worksheet.py
python inspect_pdf.py
```

PDF는 `output/`에 만들어집니다. 인터넷 연결 없이도 글꼴과 로고를 읽어 생성합니다.

## 새로 작성·축약한 내용
- 기존 시뮬레이션의 단계 설명을 단계명과 관찰 항목으로 줄였습니다.
- ‘염색체 모양·위치’, ‘방추사·핵막 변화’, ‘정렬 단위’, ‘분리되는 대상’ 등 표 라벨을 새로 붙였습니다.
- 방추사 보기 설정의 의미, 중기·후기 스케치, 염색체 수·DNA량 표, 교차 ON/OFF 비교 및 마무리 오류 수정 질문을 수업용으로 새로 작성했습니다.
- 50분 시간 배분과 책자 정보는 사용자가 승인한 제안을 반영했습니다.
- 사용자 요청으로 교사용 답안, 미제공 판권 항목, 인쇄소용 도련·재단선 PDF는 제외했습니다.
- 사진이나 인터넷 이미지를 추가하지 않았으며, 이전에 승인한 학교 수업용 로고만 사용했습니다.
- 글자 누락을 피하기 위한 기호 치환이나 본문 장평 축소는 하지 않았습니다.

## 글꼴 출처
Pretendard: https://github.com/orioncactus/pretendard
해당 저장소의 `packages/pretendard/dist/public/static/alternative/`에서 받은 네 굵기를 사용했습니다. SIL Open Font License는 `fonts/LICENSE`에 포함되어 있습니다.
로고 글씨 윤곽선의 Jua 라이선스는 `logo-font-license.txt`에 별도로 포함했습니다.
